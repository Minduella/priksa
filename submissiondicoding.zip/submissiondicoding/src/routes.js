const { 
    addBookKeeper, 
    getAllBooksKeeper, 
    getBookByIdKeeper, 
    editBookByIdKeeper, 
    deleteBookByIdKeeper, 
    
} 
= require('./Keeper');

const routes = [
    {
        method: 'POST',
        path: '/books',
        keeper: addBookKeeper,
    },

    {
        method: 'GET',
        path: '/books',
        keeper: getAllBooksKeeper,
    },

    {
        method: 'GET',
        path: '/books/{id}',
        keeper: getBookByIdKeeper,
    },

    {
        method: 'PUT',
        path: '/books/{id}',
        keeper: editBookByIdKeeper,
    },

    {
        method: 'DELETE',
        path: '/books/{id}',
        keeper: deleteBookByIdKeeper,
    },
    
];

module.exports = routes;